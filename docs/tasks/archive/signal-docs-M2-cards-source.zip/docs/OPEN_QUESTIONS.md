# Open questions

Agents: add questions here with two options and your recommendation. Do not decide them yourself.
User: answer inline with `ANSWER:`. Agents read answers before the next session.

## Q1 — Player stats
ANSWER: a (Money and Health only)

## Q2 — Tile and pixel size
ANSWER: b (32×32)

## Q3 — UI framework
ANSWER: a (UGUI)

## Q4 — Grid inventory size for the starting character
ANSWER: a (6×4 cells)

## Q5 — Starting items
ANSWER: a (placeholders ITEM_A, ITEM_B, ITEM_C)

## Q6 — Fonts
ANSWER: a (a free pixel font, but no font is chosen yet. Use Unity's default font until the user names one.)

## Q7 — Sizes and stack limits for ITEM_A, ITEM_B, ITEM_C
Options:
(a) ITEM_A 1×1, max stack 5. ITEM_B 1×2, max stack 1. ITEM_C 2×2, max stack 3. This covers single cells, tall items, and big items, so the grid logic gets exercised with varied shapes.
(b) You specify the sizes and stack limits.
Recommendation: (a), since these are placeholders and only need to test the logic.
ANSWER:
