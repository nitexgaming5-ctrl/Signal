# Progress

## Current milestone: M2 — Items and grid inventory (logic)
## Current task: M2-01 (see docs/tasks/M2-01-item-type.md)

## Milestone status
- [x] M0 Project foundation (verified: CoreInfoTests passed)
- [x] M1-01 PlayerStats (verified: 12 PlayerStats cases passed, 21 tests total in run)
- [ ] M2-01 ItemType
- [ ] M2-02 GridInventory placement
- [ ] M2-03 Remove and move
- [ ] M2-04 Rotate
- [ ] M2-05 Stacking and Add
- [ ] M2-06 ItemDefinition ScriptableObject
- [ ] M2-07 Placeholder assets (human, needs Q7)
- [ ] M3 Inventory UI
- [ ] M4 Basic world (one room)
- [ ] M5 Save and load
- [ ] M6 Time and schedule
- [ ] M7 The shop
- [ ] M8 Chemistry (first recipe)
- [ ] M9 Consequences
- [ ] M10 Second area

## Open
- Q7 sizes for ITEM_A/B/C: user to answer
- Q6 font: user to name a font, or Unity default is used
- Movement and shelter transitions: fixed by user, verified in Play mode
