# Task M2-01 — ItemType value (Core, no engine)

## Goal
A plain value that describes an item for inventory logic: identity, footprint, and stack limit. No Unity references, so it is testable in EditMode.

## Language limit
Unity 6 uses C# 9. Do NOT use `record`, file-scoped namespaces (`namespace X;`), `global using`, or C# 10+ features. Use block namespaces `namespace Signal.Core { ... }`.

## Specification
File: `Assets/_Project/Core/ItemType.cs`
- Namespace `Signal.Core`
- `public readonly struct ItemType : IEquatable<ItemType>`
- Properties (read-only): `Guid Id`, `int Width`, `int Height`, `int MaxStack`
- Constructor `ItemType(Guid id, int width, int height, int maxStack)`:
  - throws `ArgumentException` if `id == Guid.Empty`
  - throws `ArgumentOutOfRangeException` if `width < 1`, `height < 1`, or `maxStack < 1`
- Equality is by `Id` only: `Equals`, `GetHashCode`, `==`, `!=`

## Tests
File: `Assets/_Project/Tests/EditMode/Core/ItemTypeTests.cs`
- A valid ItemType exposes the values it was built with
- Width 0 is rejected
- Height -1 is rejected
- MaxStack 0 is rejected
- Guid.Empty is rejected
- Two ItemTypes with the same Id are equal even if sizes differ
- Two ItemTypes with different Ids are not equal

## Files you may touch
- Assets/_Project/Core/ItemType.cs (create)
- Assets/_Project/Tests/EditMode/Core/ItemTypeTests.cs (create)
- docs/PROGRESS.md

## Do NOT
- Reference UnityEngine
- Create ScriptableObjects, scenes, or any Game-layer code
- Create any other Core file

## Acceptance
- Files exist with the content above
- Report block filled in
- PROGRESS.md rewritten: M2-01 "awaiting user test run"
- Stop. The user runs the Test Runner.
