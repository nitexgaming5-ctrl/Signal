# Task M2-02 — GridInventory: size and placement (Core)

## Goal
A fixed-size grid (default 6×4 per Q4) that places items at a position, rejecting out-of-bounds and overlapping placements.

## Language limit
C# 9 only. No records, no file-scoped namespaces, no `global using`.

## Prerequisite
M2-01 done (ItemType exists).

## Specification
File: `Assets/_Project/Core/GridInventory.cs`
- Namespace `Signal.Core`
- `public readonly struct PlacedItem` with read-only properties: `int InstanceId`, `ItemType Type`, `int X`, `int Y`, `bool Rotated`, `int Count`
- `public sealed class GridInventory`
  - constants `DefaultWidth = 6`, `DefaultHeight = 4`
  - constructor `GridInventory(int width = DefaultWidth, int height = DefaultHeight)`; throws `ArgumentOutOfRangeException` if either is below 1
  - properties `Width`, `Height`
  - `IReadOnlyList<PlacedItem> Items` (a copy or read-only view; callers cannot mutate the internal list)
  - `bool CanPlace(ItemType type, int x, int y, bool rotated)`: true only if the footprint is fully inside the grid and overlaps no existing item. Footprint is `Width`×`Height`, swapped when `rotated`.
  - `int? Place(ItemType type, int x, int y, bool rotated = false, int count = 1)`: returns the new InstanceId, or null if rejected. Rejects when `count < 1`, `count > type.MaxStack`, or `CanPlace` is false. Instance ids start at 1 and increase.
  - `event Action<GridInventory> Changed`: fires only after a successful Place.

Footprint rule: touching edges is allowed. Two items may sit side by side without overlapping.

## Tests
File: `Assets/_Project/Tests/EditMode/Core/GridInventoryTests.cs`
- Default grid is 6 wide and 4 high
- Constructor with width 0 throws
- Placing inside bounds succeeds and returns an InstanceId ≥ 1
- Placing that extends past the right edge is rejected
- Placing at negative X is rejected
- Placing over an existing item is rejected
- Placing edge-adjacent to an existing item succeeds
- A rotated 1×3 item occupies 3×1 (swap check): it fits at X=3 in a 6×4 grid and does not fit at X=5
- Count above MaxStack is rejected
- Count 0 is rejected
- `Changed` fires once for a successful Place and not for a rejected one

## Files you may touch
- Assets/_Project/Core/GridInventory.cs (create)
- Assets/_Project/Tests/EditMode/Core/GridInventoryTests.cs (create)
- docs/PROGRESS.md

## Do NOT
- Add remove, move, rotate, or stacking logic (M2-03 to M2-05)
- Reference UnityEngine
- Add any item name or content

## Acceptance
- Files exist; report block filled in; PROGRESS.md rewritten
- Stop. The user runs the Test Runner.
