# Task M2-03 — GridInventory: remove and move (Core)

## Goal
Take items out and move them to another position, without ever leaving the grid in a broken state.

## Language limit
C# 9 only.

## Prerequisite
M2-02 done.

## Specification
Edit file: `Assets/_Project/Core/GridInventory.cs` (this card only adds members; do not change existing behaviour)
- `bool Remove(int instanceId)`: removes the item. Returns false if the id is unknown. Fires `Changed` only on success.
- `bool TryGet(int instanceId, out PlacedItem item)`: returns false and a default item if unknown.
- `bool TryMove(int instanceId, int x, int y, bool rotated)`:
  - Returns false if the id is unknown or the target is invalid.
  - The item being moved does NOT block its own new position (it may move onto its own footprint).
  - On failure nothing changes, including the old position.
  - On success updates X, Y, Rotated in place (the InstanceId and Count do not change). Fires `Changed`.

## Tests
Append to `Assets/_Project/Tests/EditMode/Core/GridInventoryTests.cs`
- Remove of an existing item returns true and the item is gone
- Remove of an unknown id returns false and fires no Changed
- TryGet returns the placed data for a known id
- Move to a free cell succeeds and TryGet shows the new X and Y
- Move onto another item fails and the original position is unchanged
- Move that overlaps only its own old footprint succeeds
- Move that goes out of bounds fails and changes nothing
- Move with an unknown id returns false

## Files you may touch
- Assets/_Project/Core/GridInventory.cs (add members only)
- Assets/_Project/Tests/EditMode/Core/GridInventoryTests.cs (append tests)
- docs/PROGRESS.md

## Do NOT
- Change how Place or CanPlace behave
- Add rotation or stacking (M2-04, M2-05)

## Acceptance
- Report block filled in; PROGRESS.md rewritten
- Stop. The user runs the Test Runner.
