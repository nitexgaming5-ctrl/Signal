# Task M2-04 — GridInventory: rotate in place (Core)

## Goal
An item can be turned 90° in place, but only if the turned footprint fits.

## Language limit
C# 9 only.

## Prerequisite
M2-03 done.

## Specification
Edit file: `Assets/_Project/Core/GridInventory.cs` (add a member only)
- `bool TryRotate(int instanceId)`:
  - Returns false if the id is unknown.
  - Keeps the same X and Y. Toggles `Rotated`.
  - Checks the rotated footprint against the grid and the other items (the item does not block itself).
  - Returns false and changes nothing if the rotated footprint does not fit.
  - On success fires `Changed`.

## Tests
Append to `Assets/_Project/Tests/EditMode/Core/GridInventoryTests.cs`
- A 1×3 item at X=0 rotates and becomes Rotated=true
- Rotating it again returns it to Rotated=false
- A 1×3 item at X=5 in a 6×4 grid cannot rotate (would extend past the edge)
- A 1×3 item cannot rotate when a neighbour blocks its new footprint; it stays unrotated
- Rotating an unknown id returns false
- A failed rotation fires no Changed event

Use `ItemType` with width 1 and height 3 for these tests, and width 3 and height 1 variants where needed. Sizes are test data only.

## Files you may touch
- Assets/_Project/Core/GridInventory.cs (add member only)
- Assets/_Project/Tests/EditMode/Core/GridInventoryTests.cs (append)
- docs/PROGRESS.md

## Do NOT
- Change other methods
- Add stacking

## Acceptance
- Report block filled in; PROGRESS.md rewritten
- Stop. The user runs the Test Runner.
