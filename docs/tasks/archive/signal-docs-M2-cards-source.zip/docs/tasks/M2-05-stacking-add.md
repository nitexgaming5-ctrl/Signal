# Task M2-05 — GridInventory: stacking and automatic placement (Core)

## Goal
`Add` puts a quantity of an item into the grid: first it tops up existing stacks of the same item, then it places new stacks in the first free spot. It returns what did not fit.

## Language limit
C# 9 only.

## Prerequisite
M2-04 done.

## Specification
Edit file: `Assets/_Project/Core/GridInventory.cs` (add member only)
- `int Add(ItemType type, int count)` returns the leftover count that could not be placed.
  - If `count < 1`, return 0 and change nothing.
  - Step 1: for every existing item with the same `Type.Id` and `Count < MaxStack`, add as much as fits (up to MaxStack). Do not move items. Fire `Changed` once if anything changed.
  - Step 2: while remaining > 0, create a new stack of `min(remaining, MaxStack)` in the first position (scan Y from 0, then X from 0) where an unrotated footprint fits. If none fits, stop.
  - Returns the remaining count that was not placed.
  - Fires `Changed` at most once per call.

Stack counts must be updated without changing InstanceId or position. To do this, PlacedItem may be replaced internally in the list with a new value, keeping the same InstanceId.

## Tests
Append to `Assets/_Project/Tests/EditMode/Core/GridInventoryTests.cs`
- Adding 3 to an empty grid returns 0 and creates one item with Count 3
- Adding 7 to an item with MaxStack 5 creates two stacks: 5 and 2
- Adding 2 when an existing stack has Count 3 and MaxStack 5 tops it up to 5 and creates no new stack
- Adding to a full grid returns the full count as leftover
- Adding 0 returns 0 and fires no Changed
- Adding a partial amount to a nearly full grid places what fits and returns the rest
- Adding never moves an existing item's X or Y

## Files you may touch
- Assets/_Project/Core/GridInventory.cs (add member only)
- Assets/_Project/Tests/EditMode/Core/GridInventoryTests.cs (append)
- docs/PROGRESS.md

## Do NOT
- Change Place, CanPlace, TryMove, or TryRotate behaviour
- Add any item content or names

## Acceptance
- Report block filled in; PROGRESS.md rewritten
- Stop. The user runs the Test Runner.
