# Task M2-06 — ItemDefinition ScriptableObject (Game layer)

## Goal
Designers create items as assets in the editor. The Game layer converts each asset into the Core `ItemType` the inventory uses. The stored Guid never changes after creation.

## Language limit
C# 9 only.

## Prerequisites
M2-05 done. Open question Q7 answered (sizes and stack limits for ITEM_A, ITEM_B, ITEM_C). If Q7 is blank, STOP and report.

## Specification
File: `Assets/_Project/Game/ItemDefinition.cs`
- Namespace `Signal.Game`
- `[CreateAssetMenu(menuName = "Signal/Item Definition", fileName = "ItemDefinition")]`
- `public sealed class ItemDefinition : ScriptableObject`
- Serialized private fields:
  - `string displayName`
  - `[SerializeField, HideInInspector] string id` holding a Guid string. Generated once when the asset is first created (Reset or OnValidate when empty). Never regenerated afterwards.
  - `int gridWidth` (min 1), `int gridHeight` (min 1), `int maxStack` (min 1)
- `public ItemType ToItemType()` returns `new ItemType(Guid.Parse(id), gridWidth, gridHeight, maxStack)`
- If `id` is empty or not a valid Guid, `ToItemType` throws with a clear message naming the asset.

## Tests
File: `Assets/_Project/Tests/EditMode/Game/ItemDefinitionTests.cs` (namespace `Signal.Game.Tests`)
- Creating the asset in a test with an assigned id converts to an ItemType with matching size and stack
- An asset with an empty id throws when converted
- Two ItemDefinitions get different ids

Use `ScriptableObject.CreateInstance<ItemDefinition>()` and set the id in the test through a test-only helper or reflection on the private field. Do not make the field public.

## Files you may touch
- Assets/_Project/Game/ItemDefinition.cs (create)
- Assets/_Project/Tests/EditMode/Game/ItemDefinitionTests.cs (create)
- docs/PROGRESS.md

## Do NOT
- Create any .asset file (the user does that in M2-07)
- Add UI, prefabs, or scenes
- Use string item ids anywhere in Core

## Acceptance
- Report block filled in; PROGRESS.md rewritten
- Stop. The user runs the Test Runner.
