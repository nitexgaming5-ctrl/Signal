# Task M2-07 — Create placeholder item assets (HUMAN task)

## Who does this
The user, in the Unity Project window. The agent only verifies the files.

## Prerequisites
M2-06 done. Q7 answered in docs/OPEN_QUESTIONS.md.

## Steps for the user
1. Right-click `Assets/_Project/Content/Items/` (create the folder if missing) > Create > Signal > Item Definition. Name it `ITEM_A`.
2. Repeat for `ITEM_B` and `ITEM_C`.
3. For each asset, set Display Name, Grid Width, Grid Height and Max Stack exactly as Q7 says.
4. Click Assets > Refresh. Check the Console.

## Agent task (verification only)
- Run `Get-ChildItem -Recurse -Filter *.asset Assets\_Project\Content\Items | Select-Object FullName` and paste the output.
- Report only files the output shows.
- Do NOT create or edit any .asset file.

## Acceptance
- Three .asset files listed
- Console clean
- PROGRESS.md: M2 complete once the user confirms
